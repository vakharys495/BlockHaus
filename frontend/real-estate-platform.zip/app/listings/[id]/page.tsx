"use client"

import { useState } from "react"
import { useParams } from "next/navigation"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  MapPin,
  Bed,
  Bath,
  Square,
  Calendar,
  Phone,
  Mail,
  Heart,
  Share2,
  ArrowLeft,
  Car,
  Wifi,
  Shield,
  Zap,
} from "lucide-react"
import Image from "next/image"
import Link from "next/link"

// Sample property data (in real app, this would come from API)
const propertyData = {
  1: {
    id: 1,
    title: "Luxury Villa in Lekki Phase 1",
    price: "₦85,000,000",
    type: "sale" as const,
    images: ["/lekki-penthouse.png", "/nigerian-luxury-home.png", "/ikoyi-villa.png"],
    location: "Lekki Phase 1, Lagos",
    beds: 4,
    baths: 3,
    sqft: 3200,
    yearBuilt: 2022,
    description:
      "This stunning luxury villa offers modern living in the heart of Lekki Phase 1. Featuring contemporary design, high-end finishes, and spacious rooms perfect for family living. The property boasts a beautiful garden, swimming pool, and 24/7 security.",
    features: ["Swimming Pool", "24/7 Security", "Parking Space", "Generator", "Air Conditioning", "Internet Ready"],
    owner: {
      name: "Chief Emeka Okafor",
      phone: "+234 801 234 5678",
      email: "emeka.okafor@gmail.com",
      image: "/professional-agent.png",
    },
  },
  2: {
    id: 2,
    title: "Modern Apartment in Victoria Island",
    price: "₦2,500,000/month",
    type: "rent" as const,
    images: ["/vi-apartment.png", "/lekki-penthouse.png", "/abuja-contemporary-home.png"],
    location: "Victoria Island, Lagos",
    beds: 3,
    baths: 2,
    sqft: 1800,
    yearBuilt: 2021,
    description:
      "Modern serviced apartment in the prestigious Victoria Island area. This fully furnished unit offers luxury amenities and is perfect for professionals seeking premium accommodation in Lagos business district.",
    features: ["Fully Furnished", "Gym Access", "Concierge Service", "Backup Power", "High-Speed Internet", "Parking"],
    owner: {
      name: "Mrs. Aisha Bello",
      phone: "+234 802 345 6789",
      email: "aisha.bello@yahoo.com",
      image: "/female-agent.png",
    },
  },
}

export default function ListingDetailsPage() {
  const params = useParams()
  const propertyId = Number.parseInt(params.id as string)
  const property = propertyData[propertyId as keyof typeof propertyData]

  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [isFavorited, setIsFavorited] = useState(false)

  if (!property) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center py-12">
            <h1 className="text-2xl font-bold mb-4">Property Not Found</h1>
            <p className="text-muted-foreground mb-6">The property you're looking for doesn't exist.</p>
            <Link href="/listings">
              <Button className="bg-slate-600 hover:bg-slate-700">Back to Listings</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <div className="mb-6">
          <Link href="/listings">
            <Button variant="ghost" className="flex items-center space-x-2">
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Listings</span>
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Image Gallery */}
            <Card>
              <CardContent className="p-0">
                <div className="relative h-96 overflow-hidden rounded-t-lg">
                  <Image
                    src={property.images[currentImageIndex] || "/placeholder.svg"}
                    alt={property.title}
                    fill
                    className="object-cover"
                  />
                  <div className="absolute top-4 left-4">
                    <Badge variant={property.type === "sale" ? "default" : "secondary"}>
                      {property.type === "sale" ? "For Sale" : "For Rent"}
                    </Badge>
                  </div>
                  <div className="absolute top-4 right-4 flex space-x-2">
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => setIsFavorited(!isFavorited)}
                      className="bg-white/90 hover:bg-white"
                    >
                      <Heart className={`w-4 h-4 ${isFavorited ? "fill-red-500 text-red-500" : ""}`} />
                    </Button>
                    <Button size="sm" variant="secondary" className="bg-white/90 hover:bg-white">
                      <Share2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Image Thumbnails */}
                {property.images.length > 1 && (
                  <div className="flex space-x-2 p-4">
                    {property.images.map((image, index) => (
                      <button
                        key={index}
                        onClick={() => setCurrentImageIndex(index)}
                        className={`relative w-20 h-16 rounded overflow-hidden border-2 ${
                          currentImageIndex === index ? "border-primary" : "border-transparent"
                        }`}
                      >
                        <Image
                          src={image || "/placeholder.svg"}
                          alt={`View ${index + 1}`}
                          fill
                          className="object-cover"
                        />
                      </button>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Property Details */}
            <Card>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-2xl mb-2">{property.title}</CardTitle>
                    <div className="flex items-center text-muted-foreground mb-4">
                      <MapPin className="w-4 h-4 mr-1" />
                      <span>{property.location}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold text-primary">{property.price}</div>
                  </div>
                </div>

                {/* Property Stats */}
                <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                  <div className="flex items-center">
                    <Bed className="w-4 h-4 mr-1" />
                    <span>{property.beds} beds</span>
                  </div>
                  <div className="flex items-center">
                    <Bath className="w-4 h-4 mr-1" />
                    <span>{property.baths} baths</span>
                  </div>
                  <div className="flex items-center">
                    <Square className="w-4 h-4 mr-1" />
                    <span>{property.sqft.toLocaleString()} sqft</span>
                  </div>
                  <div className="flex items-center">
                    <Calendar className="w-4 h-4 mr-1" />
                    <span>Built {property.yearBuilt}</span>
                  </div>
                </div>
              </CardHeader>
            </Card>

            {/* Tabs for Description and Features */}
            <Tabs defaultValue="description" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="description">Description</TabsTrigger>
                <TabsTrigger value="features">Features</TabsTrigger>
              </TabsList>

              <TabsContent value="description" className="mt-4">
                <Card>
                  <CardContent className="pt-6">
                    <p className="text-muted-foreground leading-relaxed">{property.description}</p>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="features" className="mt-4">
                <Card>
                  <CardContent className="pt-6">
                    <div className="grid grid-cols-2 gap-4">
                      {property.features.map((feature, index) => (
                        <div key={index} className="flex items-center space-x-2">
                          {feature.includes("Security") && <Shield className="w-4 h-4 text-green-600" />}
                          {feature.includes("Pool") && <Zap className="w-4 h-4 text-blue-600" />}
                          {feature.includes("Parking") && <Car className="w-4 h-4 text-gray-600" />}
                          {feature.includes("Internet") && <Wifi className="w-4 h-4 text-purple-600" />}
                          {!feature.includes("Security") &&
                            !feature.includes("Pool") &&
                            !feature.includes("Parking") &&
                            !feature.includes("Internet") && <Zap className="w-4 h-4 text-primary" />}
                          <span className="text-sm">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Contact Owner */}
            <Card>
              <CardHeader>
                <CardTitle>Contact Owner</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="relative w-12 h-12 rounded-full overflow-hidden">
                    <Image
                      src={property.owner.image || "/placeholder.svg"}
                      alt={property.owner.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <div className="font-semibold">{property.owner.name}</div>
                    <div className="text-sm text-muted-foreground">Property Owner</div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Button className="w-full flex items-center space-x-2 bg-slate-600 hover:bg-slate-700">
                    <Phone className="w-4 h-4" />
                    <span>Call Owner</span>
                  </Button>
                  <Button variant="outline" className="w-full flex items-center space-x-2 bg-transparent">
                    <Mail className="w-4 h-4" />
                    <span>Send Message</span>
                  </Button>
                </div>

                <div className="text-xs text-muted-foreground space-y-1">
                  <div className="flex items-center">
                    <Phone className="w-3 h-3 mr-1" />
                    <span>{property.owner.phone}</span>
                  </div>
                  <div className="flex items-center">
                    <Mail className="w-3 h-3 mr-1" />
                    <span>{property.owner.email}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Schedule Viewing */}
            <Card>
              <CardHeader>
                <CardTitle>Schedule a Viewing</CardTitle>
              </CardHeader>
              <CardContent>
                <Button className="w-full flex items-center space-x-2 bg-slate-600 hover:bg-slate-700">
                  <Calendar className="w-4 h-4" />
                  <span>Book Viewing</span>
                </Button>
                <p className="text-xs text-muted-foreground mt-2">
                  Available for viewing Monday to Saturday, 9 AM - 6 PM
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
