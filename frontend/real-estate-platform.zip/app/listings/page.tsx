"use client"

import { useState } from "react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { PropertyCard } from "@/components/property-card"
import { ResponsiveLayout } from "@/components/responsive-layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Search, Filter, MapPin, SlidersHorizontal } from "lucide-react"
import Link from "next/link"

const sampleProperties = [
  {
    id: 1,
    title: "Luxury Villa in Lekki Phase 1",
    starkPrice: 8500,
    type: "rent" as const,
    image: "/lekki-penthouse.png",
    location: "Lekki Phase 1, Lagos",
    beds: 4,
    baths: 3,
    sqft: 3200,
  },
  {
    id: 2,
    title: "Modern Apartment in Victoria Island",
    starkPrice: 2500,
    type: "rent" as const,
    image: "/vi-apartment.png",
    location: "Victoria Island, Lagos",
    beds: 3,
    baths: 2,
    sqft: 1800,
  },
  {
    id: 3,
    title: "Contemporary Home in Ikoyi",
    starkPrice: 12000,
    type: "rent" as const,
    image: "/ikoyi-villa.png",
    location: "Ikoyi, Lagos",
    beds: 5,
    baths: 4,
    sqft: 4500,
  },
  {
    id: 4,
    title: "Serviced Apartment in Abuja",
    starkPrice: 1800,
    type: "rent" as const,
    image: "/abuja-contemporary-home.png",
    location: "Maitama, Abuja",
    beds: 2,
    baths: 2,
    sqft: 1200,
  },
  {
    id: 5,
    title: "Luxury Estate in Banana Island",
    starkPrice: 25000,
    type: "rent" as const,
    image: "/banana-island-estate.png",
    location: "Banana Island, Lagos",
    beds: 6,
    baths: 5,
    sqft: 6000,
  },
  {
    id: 6,
    title: "Modern Duplex in Lekki",
    starkPrice: 3200,
    type: "rent" as const,
    image: "/nigerian-luxury-home.png",
    location: "Lekki Phase 2, Lagos",
    beds: 4,
    baths: 3,
    sqft: 2800,
  },
]

export default function ListingsPage() {
  const [priceRange, setPriceRange] = useState([0, 30000]) // Updated to STARK token range
  const [location, setLocation] = useState("")
  const [filteredProperties, setFilteredProperties] = useState(sampleProperties)
  const [propertyType, setPropertyType] = useState<"rent" | "all">("all")

  const handleFilter = () => {
    let filtered = sampleProperties

    // Filter by location
    if (location) {
      filtered = filtered.filter((property) => property.location.toLowerCase().includes(location.toLowerCase()))
    }

    // Filter by property type
    if (propertyType === "rent") {
      filtered = filtered.filter((property) => property.type === "rent")
    }

    filtered = filtered.filter((property) => {
      return property.starkPrice >= priceRange[0] && property.starkPrice <= priceRange[1]
    })

    setFilteredProperties(filtered)
  }

  const FilterSidebar = () => (
    <div className="space-y-6 bg-white dark:bg-gray-900 p-4 rounded-lg border border-gray-200 dark:border-gray-700 shadow-sm">
      <div className="flex items-center space-x-2 mb-4">
        <SlidersHorizontal className="w-5 h-5 text-gray-700 dark:text-gray-300" />
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Filter Properties</h2>
      </div>

      {/* Property Type Filter */}
      <div className="space-y-3">
        <Label className="text-sm font-medium text-gray-700 dark:text-gray-300">Property Type</Label>
        <div className="flex space-x-2">
          <Button
            variant={propertyType === "all" ? "default" : "outline"}
            size="sm"
            onClick={() => setPropertyType("all")}
            className={`px-4 py-2 text-sm font-medium rounded-md border transition-colors ${
              propertyType === "all"
                ? "bg-slate-600 text-white border-slate-600 hover:bg-slate-700 dark:bg-slate-700 dark:hover:bg-slate-800"
                : "bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700"
            }`}
          >
            All Properties
          </Button>
          <Button
            variant={propertyType === "rent" ? "default" : "outline"}
            size="sm"
            onClick={() => setPropertyType("rent")}
            className={`px-4 py-2 text-sm font-medium rounded-md border transition-colors ${
              propertyType === "rent"
                ? "bg-slate-600 text-white border-slate-600 hover:bg-slate-700 dark:bg-slate-700 dark:hover:bg-slate-800"
                : "bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700"
            }`}
          >
            For Rent
          </Button>
        </div>
      </div>

      {/* Price Range Filter */}
      <div className="space-y-4">
        <Label className="text-sm font-medium text-gray-700 dark:text-gray-300">Price Range (STARK/month)</Label>
        <div className="px-2">
          <Slider
            value={priceRange}
            onValueChange={setPriceRange}
            max={30000} // Updated max to STARK token range
            min={0}
            step={500}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-gray-600 dark:text-gray-400 mt-2">
            <span>{priceRange[0].toLocaleString()} STARK</span>
            <span>{priceRange[1].toLocaleString()} STARK</span>
          </div>
        </div>
      </div>

      {/* Location Search */}
      <div className="space-y-3">
        <Label className="text-sm font-medium text-gray-700 dark:text-gray-300">Location</Label>
        <div className="relative">
          <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 dark:text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search location..."
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            className="pl-10 text-sm bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500"
          />
        </div>
      </div>

      <Button
        onClick={handleFilter}
        className="w-full flex items-center justify-center space-x-2 bg-slate-600 hover:bg-slate-700 dark:bg-slate-700 dark:hover:bg-slate-800 text-white text-sm py-2"
      >
        <Filter className="w-4 h-4" />
        <span>Apply Filters</span>
      </Button>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navbar />

      <ResponsiveLayout sidebar={<FilterSidebar />}>
        {/* Page Header */}
        <div className="mb-6 lg:mb-8">
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 dark:text-white mb-2">
            Rental Properties
          </h1>
          <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400">
            Browse through all available properties for rent
          </p>
        </div>

        {/* Results Summary */}
        <div className="mb-4 lg:mb-6">
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Showing {filteredProperties.length} of {sampleProperties.length} properties
          </p>
        </div>

        {/* Property Grid - Responsive grid columns */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-6">
          {filteredProperties.map((property) => (
            <Link key={property.id} href={`/listings/${property.id}`}>
              <PropertyCard property={property} />
            </Link>
          ))}
        </div>

        {/* No Results */}
        {filteredProperties.length === 0 && (
          <div className="text-center py-8 lg:py-12">
            <div className="text-gray-600 dark:text-gray-400 mb-4">
              <Search className="w-8 h-8 sm:w-12 sm:h-12 mx-auto mb-4 opacity-50" />
              <h3 className="text-base sm:text-lg font-semibold mb-2 text-gray-900 dark:text-white">
                No properties found
              </h3>
              <p className="text-sm sm:text-base">Try adjusting your filters to see more results</p>
            </div>
            <Button
              onClick={() => {
                setPriceRange([0, 30000]) // Updated reset range
                setLocation("")
                setPropertyType("all")
                setFilteredProperties(sampleProperties)
              }}
              className="bg-slate-600 hover:bg-slate-700 dark:bg-slate-700 dark:hover:bg-slate-800 text-white text-sm sm:text-base px-4 py-2"
            >
              Clear All Filters
            </Button>
          </div>
        )}
      </ResponsiveLayout>

      <Footer />
    </div>
  )
}
