import { Navbar } from "@/components/navbar"
import { HeroBanner } from "@/components/hero-banner"
import { FeaturedListings } from "@/components/featured-listings"
import { Footer } from "@/components/footer"
import { ThemeToggle } from "@/components/theme-toggle"

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col bg-background dark:bg-background">
      <Navbar />
      <div className="fixed top-4 right-4 z-50">
        <ThemeToggle />
      </div>
      <main className="flex-1">
        <div className="px-4 sm:px-6 lg:px-8">
          <HeroBanner />
          <div className="py-8 lg:py-12">
            <FeaturedListings />
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
