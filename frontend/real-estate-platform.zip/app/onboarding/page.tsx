import { OnboardingPage } from "@/components/onboarding-page"

export default function Onboarding() {
  return <OnboardingPage />
}
