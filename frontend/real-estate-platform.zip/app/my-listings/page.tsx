import { MyListingsPage } from "@/components/my-listings-page"

export default function MyListings() {
  return <MyListingsPage />
}
