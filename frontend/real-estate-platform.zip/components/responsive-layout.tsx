"use client"

import type { ReactNode } from "react"
import { cn } from "@/lib/utils"

interface ResponsiveLayoutProps {
  sidebar?: ReactNode
  children: ReactNode
  className?: string
}

export function ResponsiveLayout({ sidebar, children, className }: ResponsiveLayoutProps) {
  return (
    <div className={cn("w-full", className)}>
      {/* Desktop Layout: Grid with sidebar */}
      <div className="hidden lg:grid lg:grid-cols-4 lg:gap-8 lg:max-w-7xl lg:mx-auto lg:px-4 lg:py-8">
        {sidebar && (
          <aside className="lg:col-span-1 lg:sticky lg:top-8 lg:h-fit">
            <div className="bg-card rounded-lg border p-6 shadow-sm">{sidebar}</div>
          </aside>
        )}
        <main className={cn("lg:col-span-3", !sidebar && "lg:col-span-4")}>{children}</main>
      </div>

      {/* Tablet Layout: Stacked with centered content */}
      <div className="hidden md:block lg:hidden max-w-4xl mx-auto px-6 py-8">
        {sidebar && (
          <div className="mb-8">
            <div className="bg-card rounded-lg border p-6 shadow-sm">{sidebar}</div>
          </div>
        )}
        <main className="w-full">{children}</main>
      </div>

      {/* Mobile Layout: Single column, full width */}
      <div className="block md:hidden px-4 py-6">
        {sidebar && (
          <div className="mb-6">
            <div className="bg-card rounded-lg border p-4 shadow-sm">{sidebar}</div>
          </div>
        )}
        <main className="w-full">{children}</main>
      </div>
    </div>
  )
}
