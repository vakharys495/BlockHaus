"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Copy, Check, LogOut, Wallet } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import Image from "next/image"
import { motion } from "framer-motion"

interface WalletAddressDisplayProps {
  address: string
  walletType: string
  onDisconnect: () => void
}

export function WalletAddressDisplay({ address, walletType, onDisconnect }: WalletAddressDisplayProps) {
  const [copied, setCopied] = useState(false)

  const shortenAddress = (addr: string) => {
    return `${addr.slice(0, 6)}...${addr.slice(-4)}`
  }

  const copyAddress = async () => {
    try {
      await navigator.clipboard.writeText(address)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (error) {
      console.error("Failed to copy address:", error)
    }
  }

  const getWalletLogo = (type: string) => {
    const logos = {
      argentx: "/argentx-logo.jpeg",
      braavos: "/braavos-logo.jpeg",
    }
    return logos[type as keyof typeof logos] || "/wallet-icon.png"
  }

  const getWalletName = (type: string) => {
    const names = {
      argentx: "Argent X",
      braavos: "Braavos",
    }
    return names[type as keyof typeof names] || "Wallet"
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          className="flex items-center space-x-3 px-3 py-2 h-10 bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800 hover:bg-green-100 dark:hover:bg-green-900/30 transition-all duration-200"
        >
          <div className="w-6 h-6 rounded-full overflow-hidden">
            <Image
              src={getWalletLogo(walletType) || "/placeholder.svg"}
              alt={getWalletName(walletType)}
              width={24}
              height={24}
              className="object-cover w-full h-full"
            />
          </div>
          <span className="font-mono text-sm font-medium text-green-700 dark:text-green-400">
            {shortenAddress(address)}
          </span>
          <div className="w-2 h-2 bg-green-500 dark:bg-green-400 rounded-full animate-pulse" />
        </Button>
      </DropdownMenuTrigger>

      <DropdownMenuContent
        align="end"
        className="w-64 p-2 bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700"
      >
        <div className="px-2 py-3 border-b border-gray-100 dark:border-gray-700">
          <div className="flex items-center space-x-3 mb-2">
            <div className="w-8 h-8 rounded-full overflow-hidden">
              <Image
                src={getWalletLogo(walletType) || "/placeholder.svg"}
                alt={getWalletName(walletType)}
                width={32}
                height={32}
                className="object-cover w-full h-full"
              />
            </div>
            <div>
              <div className="font-medium text-sm text-gray-900 dark:text-white">{getWalletName(walletType)}</div>
              <div className="text-xs text-green-600 dark:text-green-400 flex items-center space-x-1">
                <div className="w-2 h-2 bg-green-500 dark:bg-green-400 rounded-full" />
                <span>Connected</span>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-2 font-mono text-xs break-all text-gray-900 dark:text-gray-100">
            {address}
          </div>
        </div>

        <DropdownMenuItem
          onClick={copyAddress}
          className="cursor-pointer text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
        >
          <motion.div className="flex items-center space-x-2 w-full" whileTap={{ scale: 0.95 }}>
            {copied ? <Check className="w-4 h-4 text-green-600 dark:text-green-400" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? "Copied!" : "Copy Address"}</span>
          </motion.div>
        </DropdownMenuItem>

        <DropdownMenuItem className="cursor-pointer text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700">
          <Wallet className="w-4 h-4 mr-2" />
          View on Explorer
        </DropdownMenuItem>

        <DropdownMenuSeparator className="bg-gray-200 dark:bg-gray-600" />

        <DropdownMenuItem
          onClick={onDisconnect}
          className="cursor-pointer text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 focus:text-red-600 dark:focus:text-red-400"
        >
          <LogOut className="w-4 h-4 mr-2" />
          Disconnect
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
