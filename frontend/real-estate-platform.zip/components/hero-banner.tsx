"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, MapPin } from "lucide-react"

export function HeroBanner() {
  const [searchFilters, setSearchFilters] = useState({
    location: "",
    priceRange: "",
  })

  const handleSearch = () => {
    console.log("Searching with filters:", searchFilters)
  }

  return (
    <section className="relative h-[70vh] flex items-center justify-center">
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url('/nigerian-luxury-home.png')`,
        }}
      >
        <div className="absolute inset-0 bg-black/40 dark:bg-black/60" />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center text-white max-w-4xl mx-auto px-4">
        <h1 className="text-4xl md:text-6xl font-bold mb-6 text-white dark:text-white">Find Your Dream Rental</h1>
        <p className="text-xl md:text-2xl mb-8 text-white/90 dark:text-white/80">
          Discover premium rental properties powered by BLOKHAUS blockchain technology
        </p>

        {/* Search Bar */}
        <div className="bg-white/95 dark:bg-gray-900/95 backdrop-blur-sm rounded-lg p-6 shadow-xl">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-600 dark:text-gray-300 flex items-center">
                <MapPin className="w-4 h-4 mr-1" />
                Location
              </label>
              <Input
                placeholder="Enter city or area"
                value={searchFilters.location}
                onChange={(e) => setSearchFilters({ ...searchFilters, location: e.target.value })}
                className="bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-600 dark:text-gray-300 flex items-center">
                <span className="w-4 h-4 mr-1 text-sm font-bold">⚡</span>
                Monthly Rent (STARK)
              </label>
              <Select onValueChange={(value) => setSearchFilters({ ...searchFilters, priceRange: value })}>
                <SelectTrigger className="bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white">
                  <SelectValue placeholder="Select range" className="placeholder-gray-400 dark:placeholder-gray-500" />
                </SelectTrigger>
                <SelectContent className="bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600">
                  <SelectItem
                    value="0-2500"
                    className="text-gray-900 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-700"
                  >
                    0 - 2.5K STARK/month
                  </SelectItem>
                  <SelectItem
                    value="2500-5000"
                    className="text-gray-900 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-700"
                  >
                    2.5K - 5K STARK/month
                  </SelectItem>
                  <SelectItem
                    value="5000-10000"
                    className="text-gray-900 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-700"
                  >
                    5K - 10K STARK/month
                  </SelectItem>
                  <SelectItem
                    value="10000+"
                    className="text-gray-900 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-700"
                  >
                    10K+ STARK/month
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button onClick={handleSearch} size="lg" className="w-full bg-slate-600 hover:bg-slate-700">
              <Search className="w-4 h-4 mr-2" />
              Search Rentals
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
