"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"

const propertyImages = [
  "/nigerian-luxury-home.png",
  "/lekki-penthouse.png",
  "/ikoyi-villa.png",
  "/abuja-contemporary-home.png",
  "/vi-apartment.png",
  "/banana-island-estate.png",
  "/placeholder-6yro2.png",
  "/luxury-abuja-villa.png",
  "/contemporary-nigerian-home.png",
  "/elegant-property-nigeria.png",
]

export function NewLandingPage() {
  const [currentImageIndex, setCurrentImageIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % propertyImages.length)
    }, 10000) // Change every 10 seconds

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background Slideshow */}
      <div className="absolute inset-0 z-0">
        {propertyImages.map((image, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentImageIndex ? "opacity-100" : "opacity-0"
            }`}
          >
            <Image
              src={image || "/placeholder.svg"}
              alt={`Property ${index + 1}`}
              fill
              className="object-cover"
              priority={index === 0}
            />
          </div>
        ))}
        {/* Dark overlay for text readability */}
        <div className="absolute inset-0 bg-black/50" />
      </div>

      {/* Header */}
      <header className="relative z-10 flex items-center justify-between p-6">
        <div className="flex items-center gap-3">
          <Image src="/blockhaus-logo-cropped.png" alt="BLOKHAUS Logo" width={40} height={40} className="rounded-lg" />
          <span className="text-white font-black text-xl tracking-wide">BLOKHAUS</span>
        </div>
      </header>

      {/* Main Content */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-[80vh] px-6 text-center">
        <h1 className="text-white text-4xl md:text-6xl font-black mb-8 max-w-4xl leading-tight">
          WE BRING YOUR HOUSING REALITIES TO LIFE
        </h1>

        <div className="flex flex-col sm:flex-row gap-4 mt-8">
          <Link href="/onboarding">
            <Button
              size="lg"
              className="bg-slate-600 hover:bg-slate-700 text-white font-bold px-8 py-4 text-lg rounded-lg min-w-[140px]"
            >
              LOG IN
            </Button>
          </Link>
          <Link href="/onboarding">
            <Button
              size="lg"
              className="bg-slate-600 hover:bg-slate-700 text-white font-bold px-8 py-4 text-lg rounded-lg min-w-[140px]"
            >
              GET STARTED
            </Button>
          </Link>
        </div>
      </div>

      {/* Bottom Navigation Dots */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10 flex gap-2">
        {propertyImages.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentImageIndex(index)}
            className={`w-3 h-3 rounded-full transition-all ${
              index === currentImageIndex ? "bg-slate-600" : "bg-white/50 hover:bg-white/70"
            }`}
          />
        ))}
      </div>
    </div>
  )
}
