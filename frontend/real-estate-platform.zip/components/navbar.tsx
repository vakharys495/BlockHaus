"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, X, User, Settings, History, LogOut, Wallet, Sun, Moon } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import Image from "next/image"
import { WalletConnectionModal } from "./wallet-connection-modal"
import { WalletAddressDisplay } from "./wallet-address-display"

export function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [walletDialogOpen, setWalletDialogOpen] = useState(false)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [userType, setUserType] = useState<string | null>(null)
  const [connectedWallet, setConnectedWallet] = useState<{
    address: string
    walletType: string
  } | null>(null)

  useEffect(() => {
    const storedUserType = localStorage.getItem("userType")
    const storedWallet = localStorage.getItem("connectedWallet")
    const storedTheme = localStorage.getItem("theme")

    if (storedUserType) {
      setIsAuthenticated(true)
      setUserType(storedUserType)
    }

    if (storedWallet) {
      try {
        setConnectedWallet(JSON.parse(storedWallet))
      } catch (error) {
        console.error("Failed to parse stored wallet:", error)
        localStorage.removeItem("connectedWallet")
      }
    }

    if (storedTheme) {
      document.documentElement.classList.add(storedTheme)
    }
  }, [])

  const navLinks = [
    { href: "/", label: "Home" },
    { href: "/listings", label: "Listings" },
    ...(isAuthenticated ? [{ href: "/my-listings", label: "My Listings" }] : []),
  ]

  const handleWalletConnect = (address: string, walletType: string) => {
    const walletData = { address, walletType }
    setConnectedWallet(walletData)
    localStorage.setItem("connectedWallet", JSON.stringify(walletData))
  }

  const handleWalletDisconnect = () => {
    setConnectedWallet(null)
    localStorage.removeItem("connectedWallet")
  }

  const handleLogout = () => {
    localStorage.removeItem("userType")
    localStorage.removeItem("connectedWallet")
    localStorage.removeItem("theme")
    setIsAuthenticated(false)
    setUserType(null)
    setConnectedWallet(null)
    window.location.href = "/"
  }

  return (
    <nav className="bg-white/95 dark:bg-gray-900/95 backdrop-blur-sm border-b border-border dark:border-gray-700 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-8">
        <div className="flex justify-between items-center h-16 sm:h-18 lg:h-20">
          {/* Logo - Responsive sizing */}
          <Link
            href="/"
            className="flex items-center space-x-2 sm:space-x-3 lg:space-x-4 hover:opacity-80 transition-opacity"
          >
            <Image
              src="/blockhaus-logo-cropped.png"
              alt="BLOKHAUS"
              width={40}
              height={40}
              className="object-contain sm:w-[45px] sm:h-[45px] lg:w-[50px] lg:h-[50px]"
            />
            <span className="text-lg sm:text-xl lg:text-2xl font-black tracking-wide text-gray-900 dark:text-white">
              BLOKHAUS
            </span>
          </Link>

          {/* Desktop Navigation - Better spacing */}
          <div className="hidden lg:flex items-center space-x-6 xl:space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-sm xl:text-base text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors font-medium"
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* Desktop Actions - Fixed spacing and alignment */}
          <div className="hidden lg:flex items-center justify-end gap-3">
            {!isAuthenticated ? (
              <Link href="/onboarding">
                <Button className="bg-slate-600 hover:bg-slate-700 text-white font-semibold text-sm xl:text-base px-4 xl:px-6">
                  Sign In
                </Button>
              </Link>
            ) : (
              <div className="flex items-center gap-3">
                {connectedWallet ? (
                  <WalletAddressDisplay
                    address={connectedWallet.address}
                    walletType={connectedWallet.walletType}
                    onDisconnect={handleWalletDisconnect}
                  />
                ) : (
                  <Button
                    variant="outline"
                    className="flex items-center space-x-2 bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900/30 text-sm xl:text-base"
                    onClick={() => setWalletDialogOpen(true)}
                  >
                    <Wallet className="w-4 h-4" />
                    <span>Connect Wallet</span>
                  </Button>
                )}

                <WalletConnectionModal
                  isOpen={walletDialogOpen}
                  onOpenChange={setWalletDialogOpen}
                  onWalletConnect={handleWalletConnect}
                />

                <div className="flex items-center gap-2">
                  {/* User Profile Dropdown */}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="outline"
                        className="flex items-center space-x-2 bg-transparent border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 text-sm xl:text-base"
                      >
                        <User className="w-5 h-5" />
                        <span className="hidden xl:inline">Profile</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent
                      align="end"
                      className="w-48 bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700"
                    >
                      <DropdownMenuItem className="text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700">
                        <User className="w-4 h-4 mr-2" />
                        Profile
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700">
                        <History className="w-4 h-4 mr-2" />
                        History
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700">
                        <Settings className="w-4 h-4 mr-2" />
                        Settings
                      </DropdownMenuItem>
                      <DropdownMenuSeparator className="bg-gray-200 dark:bg-gray-600" />
                      <DropdownMenuItem
                        className="text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20"
                        onClick={handleLogout}
                      >
                        <LogOut className="w-4 h-4 mr-2" />
                        Logout
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>

                  {/* Theme Toggle */}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const currentTheme = document.documentElement.classList.contains("dark") ? "dark" : "light"
                      const newTheme = currentTheme === "light" ? "dark" : "light"
                      if (newTheme === "dark") {
                        document.documentElement.classList.add("dark")
                      } else {
                        document.documentElement.classList.remove("dark")
                      }
                      localStorage.setItem("theme", newTheme)
                    }}
                    className="bg-transparent border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800"
                  >
                    <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                    <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
                    <span className="sr-only">Toggle theme</span>
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Mobile menu button - Better positioning */}
          <div className="lg:hidden">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 text-gray-700 dark:text-gray-300"
            >
              {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation - Enhanced mobile experience */}
        {isMenuOpen && (
          <div className="lg:hidden py-4 border-t border-gray-200 dark:border-gray-700 animate-in slide-in-from-top-2 duration-200">
            <div className="flex flex-col space-y-3">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="text-base text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors py-2 px-2 rounded-md hover:bg-gray-50 dark:hover:bg-gray-800"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {link.label}
                </Link>
              ))}
              <div className="pt-3 border-t border-gray-200 dark:border-gray-700">
                {!isAuthenticated ? (
                  <Link href="/onboarding" onClick={() => setIsMenuOpen(false)}>
                    <Button className="w-full bg-slate-600 hover:bg-slate-700 text-white font-semibold">Sign In</Button>
                  </Link>
                ) : (
                  <div className="space-y-2">
                    {connectedWallet ? (
                      <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
                        <div className="text-sm font-medium text-green-700 dark:text-green-400">Wallet Connected</div>
                        <div className="text-xs font-mono text-green-600 dark:text-green-300 mt-1">
                          {connectedWallet.address.slice(0, 6)}...{connectedWallet.address.slice(-4)}
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="mt-2 text-xs text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300 p-0 h-auto"
                          onClick={handleWalletDisconnect}
                        >
                          Disconnect
                        </Button>
                      </div>
                    ) : (
                      <Button
                        variant="ghost"
                        className="w-full justify-start py-3 text-base bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900/30 border border-blue-200 dark:border-blue-800"
                        onClick={() => {
                          setWalletDialogOpen(true)
                          setIsMenuOpen(false)
                        }}
                      >
                        <Wallet className="w-4 h-4 mr-3" />
                        Connect Wallet
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      className="w-full justify-start py-3 text-base text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800"
                    >
                      <User className="w-4 h-4 mr-3" />
                      Profile
                    </Button>
                    <Button
                      variant="ghost"
                      className="w-full justify-start py-3 text-base text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800"
                    >
                      <History className="w-4 h-4 mr-3" />
                      History
                    </Button>
                    <Button
                      variant="ghost"
                      className="w-full justify-start py-3 text-base text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800"
                    >
                      <Settings className="w-4 h-4 mr-3" />
                      Settings
                    </Button>
                    <Button
                      variant="ghost"
                      className="w-full justify-start py-3 text-base text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300 hover:bg-red-50 dark:hover:bg-red-900/20"
                      onClick={handleLogout}
                    >
                      <LogOut className="w-4 h-4 mr-3" />
                      Logout
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}
