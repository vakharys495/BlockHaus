import Link from "next/link"
import { Facebook, Twitter, Instagram, Linkedin } from "lucide-react"
import Image from "next/image"

export function Footer() {
  return (
    <footer className="bg-muted/50 border-t border-border">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <Image
                src="/blockhaus-logo-cropped.png"
                alt="BLOKHAUS"
                width={40}
                height={40}
                className="object-contain"
              />
              <span className="font-bold text-xl" style={{ fontFamily: "var(--font-montserrat)", fontWeight: 900 }}>
                BLOKHAUS
              </span>
            </div>
            <p className="text-muted-foreground">
              The future of real estate powered by blockchain technology. Find, buy, and sell properties with complete
              transparency across Nigeria.
            </p>
            <div className="flex space-x-4">
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <Facebook className="w-5 h-5" />
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <Twitter className="w-5 h-5" />
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <Instagram className="w-5 h-5" />
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <Linkedin className="w-5 h-5" />
              </Link>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="font-semibold">Quick Links</h3>
            <div className="space-y-2">
              <Link href="/listings" className="block text-muted-foreground hover:text-foreground">
                Browse Listings
              </Link>
              <Link href="/my-listings" className="block text-muted-foreground hover:text-foreground">
                My Properties
              </Link>
              <Link href="/rentals" className="block text-muted-foreground hover:text-foreground">
                Rental Properties
              </Link>
            </div>
          </div>

          {/* Services */}
          <div className="space-y-4">
            <h3 className="font-semibold">Services</h3>
            <div className="space-y-2">
              <Link href="#" className="block text-muted-foreground hover:text-foreground">
                Property Valuation
              </Link>
              <Link href="#" className="block text-muted-foreground hover:text-foreground">
                Smart Contracts
              </Link>
              <Link href="#" className="block text-muted-foreground hover:text-foreground">
                Investment Analysis
              </Link>
              <Link href="#" className="block text-muted-foreground hover:text-foreground">
                Property Management
              </Link>
            </div>
          </div>

          {/* Contact */}
          <div className="space-y-4">
            <h3 className="font-semibold">Contact</h3>
            <div className="space-y-2 text-muted-foreground">
              <p>THEBUIDL GRID</p>
              <p>10 Algeria Crescent Barnawa</p>
              <p>Kaduna, Nigeria</p>
              <p>Phone: +234 803 123 4567</p>
              <p>Email: info@blokhaus.com</p>
            </div>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-8 text-center text-muted-foreground">
          <p>&copy; 2024 BLOKHAUS Platform. All rights reserved. Built with Web3 technology.</p>
        </div>
      </div>
    </footer>
  )
}
