"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Wallet, ExternalLink, X, Plus } from "lucide-react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import Image from "next/image"
import { motion, AnimatePresence } from "framer-motion"

interface WalletConnectionModalProps {
  isOpen: boolean
  onOpenChange: (open: boolean) => void
  onWalletConnect: (address: string, walletType: string) => void
}

export function WalletConnectionModal({ isOpen, onOpenChange, onWalletConnect }: WalletConnectionModalProps) {
  const [isConnecting, setIsConnecting] = useState(false)
  const [connectionError, setConnectionError] = useState<string | null>(null)
  const [showCustomWallet, setShowCustomWallet] = useState(false)
  const [customWalletAddress, setCustomWalletAddress] = useState("")

  const wallets = [
    {
      id: "argentx",
      name: "Argent X",
      description: "The most popular Starknet wallet",
      logo: "/argentx-logo.jpeg",
      isInstalled: false,
    },
    {
      id: "braavos",
      name: "Braavos",
      description: "Advanced Starknet wallet with enhanced security",
      logo: "/braavos-logo.jpeg",
      isInstalled: false,
    },
  ]

  useEffect(() => {
    // Check if wallets are installed
    const checkWalletInstallation = () => {
      // In a real implementation, you would check for wallet extensions
      // For demo purposes, we'll simulate this
      wallets.forEach((wallet) => {
        wallet.isInstalled = Math.random() > 0.5 // Random for demo
      })
    }

    if (isOpen) {
      checkWalletInstallation()
    }
  }, [isOpen])

  const connectWallet = async (walletId: string) => {
    setIsConnecting(true)
    setConnectionError(null)

    try {
      // Simulate wallet connection process
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // In a real implementation, you would use get-starknet or @starknet-react/core
      // For demo purposes, we'll generate a mock address
      const mockAddress = `0x${Math.random().toString(16).substr(2, 40)}`

      onWalletConnect(mockAddress, walletId)
      onOpenChange(false)
    } catch (error) {
      setConnectionError("Failed to connect wallet. Please try again.")
    } finally {
      setIsConnecting(false)
    }
  }

  const connectCustomWallet = async () => {
    if (!customWalletAddress.trim()) {
      setConnectionError("Please enter a valid wallet address")
      return
    }

    setIsConnecting(true)
    setConnectionError(null)

    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))
      onWalletConnect(customWalletAddress, "custom")
      onOpenChange(false)
      setCustomWalletAddress("")
      setShowCustomWallet(false)
    } catch (error) {
      setConnectionError("Failed to connect custom wallet. Please try again.")
    } finally {
      setIsConnecting(false)
    }
  }

  const installWallet = (walletId: string) => {
    const urls = {
      argentx: "https://chrome.google.com/webstore/detail/argent-x/dlcobpjiigpikoobohmabehhmhfoodbb",
      braavos: "https://chrome.google.com/webstore/detail/braavos-wallet/jnlgamecbpmbajjfhmmmlhejkemejdma",
    }

    window.open(urls[walletId as keyof typeof urls], "_blank")
  }

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[480px] p-0 overflow-hidden bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.2 }}
          className="p-6"
        >
          <DialogHeader className="space-y-3">
            <DialogTitle className="text-xl font-semibold flex items-center space-x-2 text-gray-900 dark:text-white">
              <Wallet className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              <span>Connect Wallet</span>
            </DialogTitle>
            <DialogDescription className="text-sm text-gray-600 dark:text-gray-300">
              Connect your Starknet wallet to access all features of BLOKHAUS
            </DialogDescription>
          </DialogHeader>

          <div className="mt-6 space-y-3">
            <AnimatePresence>
              {wallets.map((wallet, index) => (
                <motion.div
                  key={wallet.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="group"
                >
                  <Button
                    variant="outline"
                    className="w-full h-16 flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 border-gray-200 dark:border-gray-600 transition-all duration-200 group-hover:shadow-md"
                    onClick={() => (wallet.isInstalled ? connectWallet(wallet.id) : installWallet(wallet.id))}
                    disabled={isConnecting}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 rounded-full overflow-hidden bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600">
                        <Image
                          src={wallet.logo || "/placeholder.svg"}
                          alt={wallet.name}
                          width={40}
                          height={40}
                          className="object-cover w-full h-full"
                        />
                      </div>
                      <div className="text-left">
                        <div className="font-medium text-sm text-gray-900 dark:text-white">{wallet.name}</div>
                        <div className="text-xs text-gray-600 dark:text-gray-300">{wallet.description}</div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      {wallet.isInstalled ? (
                        <>
                          {isConnecting ? (
                            <div className="w-4 h-4 border-2 border-blue-600 dark:border-blue-400 border-t-transparent rounded-full animate-spin" />
                          ) : (
                            <ExternalLink className="w-4 h-4 text-gray-500 dark:text-gray-400 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors" />
                          )}
                        </>
                      ) : (
                        <span className="text-xs bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-300 px-2 py-1 rounded-full">
                          Install
                        </span>
                      )}
                    </div>
                  </Button>
                </motion.div>
              ))}

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="group"
              >
                {!showCustomWallet ? (
                  <Button
                    variant="outline"
                    className="w-full h-16 flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 border-gray-200 dark:border-gray-600 transition-all duration-200 group-hover:shadow-md"
                    onClick={() => setShowCustomWallet(true)}
                    disabled={isConnecting}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 rounded-full bg-gray-100 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 flex items-center justify-center">
                        <Plus className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                      </div>
                      <div className="text-left">
                        <div className="font-medium text-sm text-gray-900 dark:text-white">Custom Wallet</div>
                        <div className="text-xs text-gray-600 dark:text-gray-300">Add your own wallet address</div>
                      </div>
                    </div>
                    <ExternalLink className="w-4 h-4 text-gray-500 dark:text-gray-400 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors" />
                  </Button>
                ) : (
                  <div className="border border-gray-200 dark:border-gray-600 rounded-lg p-4 space-y-4 bg-gray-50 dark:bg-gray-800">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium text-sm text-gray-900 dark:text-white">Add Custom Wallet</h4>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setShowCustomWallet(false)
                          setCustomWalletAddress("")
                        }}
                        className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="custom-address" className="text-sm text-gray-700 dark:text-gray-300">
                        Wallet Address
                      </Label>
                      <Input
                        id="custom-address"
                        placeholder="0x..."
                        value={customWalletAddress}
                        onChange={(e) => setCustomWalletAddress(e.target.value)}
                        className="font-mono text-sm bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-600 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500"
                      />
                    </div>
                    <Button
                      onClick={connectCustomWallet}
                      disabled={isConnecting || !customWalletAddress.trim()}
                      className="w-full bg-slate-600 hover:bg-slate-700 dark:bg-slate-700 dark:hover:bg-slate-800 text-white"
                    >
                      {isConnecting ? (
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                      ) : null}
                      Connect Custom Wallet
                    </Button>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>

            {connectionError && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg flex items-center space-x-2 text-sm text-red-700 dark:text-red-300"
              >
                <X className="w-4 h-4" />
                <span>{connectionError}</span>
              </motion.div>
            )}
          </div>

          <div className="mt-6 pt-4 border-t border-gray-100 dark:border-gray-700">
            <p className="text-xs text-gray-500 dark:text-gray-400 text-center">
              By connecting a wallet, you agree to BLOKHAUS{" "}
              <a href="#" className="text-blue-600 dark:text-blue-400 hover:underline">
                Terms of Service
              </a>{" "}
              and{" "}
              <a href="#" className="text-blue-600 dark:text-blue-400 hover:underline">
                Privacy Policy
              </a>
            </p>
          </div>
        </motion.div>
      </DialogContent>
    </Dialog>
  )
}
