import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin, Bed, Bath, Square } from "lucide-react"
import { StarkPriceDisplay } from "@/components/stark-price-display"

interface Property {
  id: number
  title: string
  starkPrice: number
  type: "rent" // Changed from "sale" | "rent" to only "rent"
  image: string
  location: string
  beds: number
  baths: number
  sqft: number
}

interface PropertyCardProps {
  property: Property
}

export function PropertyCard({ property }: PropertyCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer group bg-card dark:bg-card border-0 shadow-sm">
      <div className="relative h-48 overflow-hidden rounded-t-lg">
        <Image
          src={property.image || "/placeholder.svg"}
          alt={property.title}
          fill
          className="object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <Badge
          variant="secondary"
          className="absolute top-3 left-3 bg-blue-600 dark:bg-blue-700 text-white px-3 py-1 rounded-full font-medium shadow-sm"
        >
          For Rent
        </Badge>
      </div>

      <CardContent className="p-6 bg-card dark:bg-card">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-semibold text-lg line-clamp-1 text-foreground dark:text-foreground">{property.title}</h3>
          <StarkPriceDisplay starkPrice={property.starkPrice} className="text-right" />
        </div>

        <div className="flex items-center text-muted-foreground mb-4">
          <MapPin className="w-4 h-4 mr-1" />
          <span className="text-sm">{property.location}</span>
        </div>

        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <div className="flex items-center">
            <Bed className="w-4 h-4 mr-1" />
            <span>{property.beds} beds</span>
          </div>
          <div className="flex items-center">
            <Bath className="w-4 h-4 mr-1" />
            <span>{property.baths} baths</span>
          </div>
          <div className="flex items-center">
            <Square className="w-4 h-4 mr-1" />
            <span>{property.sqft.toLocaleString()} sqft</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
