interface StarkPriceDisplayProps {
  starkPrice: number
  className?: string
}

export function StarkPriceDisplay({ starkPrice, className = "" }: StarkPriceDisplayProps) {
  return (
    <div className={`flex flex-col ${className}`}>
      <span className="font-bold text-lg text-primary dark:text-primary-foreground">
        {starkPrice.toLocaleString()} STARK
      </span>
    </div>
  )
}
