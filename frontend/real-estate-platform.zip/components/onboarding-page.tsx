"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { ChevronDown } from "lucide-react"

const propertyImages = [
  "/nigerian-luxury-home.png",
  "/lekki-penthouse.png",
  "/ikoyi-villa.png",
  "/abuja-contemporary-home.png",
  "/vi-apartment.png",
  "/banana-island-estate.png",
  "/placeholder-6yro2.png",
  "/luxury-abuja-villa.png",
  "/contemporary-nigerian-home.png",
  "/elegant-property-nigeria.png",
]

export function OnboardingPage() {
  const router = useRouter()
  const [selectedUserType, setSelectedUserType] = useState<string>("")
  const [emailDialogOpen, setEmailDialogOpen] = useState(false)
  const [googleDialogOpen, setGoogleDialogOpen] = useState(false)
  const [appleDialogOpen, setAppleDialogOpen] = useState(false)
  const [email, setEmail] = useState("")
  const [appleId, setAppleId] = useState("")
  const [currentImageIndex, setCurrentImageIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % propertyImages.length)
    }, 10000) // Change every 10 seconds

    return () => clearInterval(interval)
  }, [])

  const handleSignIn = (type: string) => {
    if (selectedUserType) {
      localStorage.setItem("userType", selectedUserType)
      localStorage.setItem("isAuthenticated", "true")
    }
    // Close all dialogs
    setEmailDialogOpen(false)
    setGoogleDialogOpen(false)
    setAppleDialogOpen(false)
    // Redirect to home page
    router.push("/")
  }

  return (
    <div className="min-h-screen relative overflow-hidden flex flex-col bg-white dark:bg-gray-900">
      {/* Background Slideshow */}
      <div className="absolute inset-0 z-0">
        {propertyImages.map((image, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentImageIndex ? "opacity-100" : "opacity-0"
            }`}
          >
            <Image
              src={image || "/placeholder.svg"}
              alt={`Property ${index + 1}`}
              fill
              className="object-cover"
              priority={index === 0}
            />
          </div>
        ))}
        <div className="absolute inset-0 bg-white/80 dark:bg-black/60 backdrop-blur-sm" />
      </div>

      {/* Header */}
      <header className="relative z-10 flex items-center justify-between p-4 md:p-6 bg-white/95 dark:bg-gray-900/95 backdrop-blur-sm border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center gap-2 md:gap-3">
          <Image
            src="/blockhaus-logo-cropped.png"
            alt="BLOKHAUS Logo"
            width={32}
            height={32}
            className="md:w-10 md:h-10 rounded-lg"
          />
          <span className="text-[#1e3a8a] dark:text-blue-400 font-black text-lg md:text-xl tracking-wide">
            BLOKHAUS
          </span>
        </div>

        {/* Select User Dropdown */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="outline"
              className="bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 text-sm md:text-base px-3 md:px-4"
            >
              {selectedUserType || "Select User"}
              <ChevronDown className="ml-1 md:ml-2 h-3 w-3 md:h-4 md:w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-600">
            <DropdownMenuItem
              onClick={() => setSelectedUserType("Owner")}
              className="cursor-pointer text-gray-900 dark:text-gray-100 hover:bg-gray-50 dark:hover:bg-gray-700"
            >
              Owner
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => setSelectedUserType("User")}
              className="cursor-pointer text-gray-900 dark:text-gray-100 hover:bg-gray-50 dark:hover:bg-gray-700"
            >
              User
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </header>

      {/* Main Content */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-4 md:px-6 text-center py-8">
        <div className="bg-white/95 dark:bg-gray-900/95 backdrop-blur-sm rounded-2xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 md:p-8 w-full max-w-sm md:max-w-md">
          <h1 className="text-[#1e3a8a] dark:text-blue-400 text-2xl md:text-3xl font-black mb-2">WELCOME TO</h1>
          <h2 className="text-[#1e3a8a] dark:text-blue-400 text-3xl md:text-4xl font-black mb-6 md:mb-8">BLOKHAUS</h2>

          <p className="text-gray-600 dark:text-gray-300 text-sm mb-6 md:mb-8">
            Join our community and discover amazing properties
          </p>

          {/* Sign-in Options */}
          <div className="space-y-3 md:space-y-4">
            {/* Sign in with Google */}
            <Dialog open={googleDialogOpen} onOpenChange={setGoogleDialogOpen}>
              <DialogTrigger asChild>
                <Button className="w-full bg-slate-600 hover:bg-slate-700 dark:bg-slate-700 dark:hover:bg-slate-800 text-white font-semibold py-2.5 md:py-3 text-sm md:text-base">
                  SIGN IN WITH GOOGLE
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md mx-4 bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-700">
                <DialogHeader>
                  <DialogTitle className="text-gray-900 dark:text-white">Sign in with Google</DialogTitle>
                </DialogHeader>
                <div className="space-y-6">
                  <div className="space-y-3">
                    <Label htmlFor="google-email" className="text-gray-700 dark:text-gray-300">
                      Email Address
                    </Label>
                    <Input
                      id="google-email"
                      type="email"
                      placeholder="Enter your email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500"
                    />
                  </div>
                  <Button
                    onClick={() => handleSignIn("google")}
                    className="w-full bg-slate-600 hover:bg-slate-700 dark:bg-slate-700 dark:hover:bg-slate-800"
                  >
                    Submit
                  </Button>
                </div>
              </DialogContent>
            </Dialog>

            {/* Sign in with Email */}
            <Dialog open={emailDialogOpen} onOpenChange={setEmailDialogOpen}>
              <DialogTrigger asChild>
                <Button className="w-full bg-slate-600 hover:bg-slate-700 dark:bg-slate-700 dark:hover:bg-slate-800 text-white font-semibold py-2.5 md:py-3 text-sm md:text-base">
                  SIGN IN WITH EMAIL
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md mx-4 bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-700">
                <DialogHeader>
                  <DialogTitle className="text-gray-900 dark:text-white">Sign in with Email</DialogTitle>
                </DialogHeader>
                <div className="space-y-6">
                  <div className="space-y-3">
                    <Label htmlFor="email" className="text-gray-700 dark:text-gray-300">
                      Email Address
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter your email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500"
                    />
                  </div>
                  <Button
                    onClick={() => handleSignIn("email")}
                    className="w-full bg-slate-600 hover:bg-slate-700 dark:bg-slate-700 dark:hover:bg-slate-800"
                  >
                    Submit
                  </Button>
                </div>
              </DialogContent>
            </Dialog>

            {/* Sign in with Apple */}
            <Dialog open={appleDialogOpen} onOpenChange={setAppleDialogOpen}>
              <DialogTrigger asChild>
                <Button className="w-full bg-slate-600 hover:bg-slate-700 dark:bg-slate-700 dark:hover:bg-slate-800 text-white font-semibold py-2.5 md:py-3 text-sm md:text-base">
                  SIGN IN WITH APPLE
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md mx-4 bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-700">
                <DialogHeader>
                  <DialogTitle className="text-gray-900 dark:text-white">Sign in with Apple</DialogTitle>
                </DialogHeader>
                <div className="space-y-6">
                  <div className="space-y-3">
                    <Label htmlFor="apple-id" className="text-gray-700 dark:text-gray-300">
                      Apple ID
                    </Label>
                    <Input
                      id="apple-id"
                      type="text"
                      placeholder="Enter your Apple ID"
                      value={appleId}
                      onChange={(e) => setAppleId(e.target.value)}
                      className="w-full bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500"
                    />
                  </div>
                  <Button
                    onClick={() => handleSignIn("apple")}
                    className="w-full bg-slate-600 hover:bg-slate-700 dark:bg-slate-700 dark:hover:bg-slate-800"
                  >
                    Submit
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Footer Links */}
        <div className="mt-6 md:mt-8 flex gap-4 md:gap-6 text-gray-500 dark:text-gray-400 text-xs md:text-sm">
          <Link href="/terms" className="hover:text-gray-700 dark:hover:text-gray-200">
            Terms
          </Link>
          <Link href="/privacy" className="hover:text-gray-700 dark:hover:text-gray-200">
            Privacy Policy
          </Link>
        </div>
      </div>
    </div>
  )
}
