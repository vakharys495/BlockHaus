"use client"

import { useEffect, useState } from "react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { AlertCircle } from "lucide-react"

export function MyListingsPage() {
  const [userType, setUserType] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check user type from localStorage
    const storedUserType = localStorage.getItem("userType")
    setUserType(storedUserType)
    setIsLoading(false)
  }, [])

  const handleRegisterAsOwner = () => {
    localStorage.setItem("userType", "Owner")
    setUserType("Owner")
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center">Loading...</div>
        </div>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {userType !== "Owner" ? (
          // Show access denied message for non-owners
          <div className="flex items-center justify-center min-h-[60vh]">
            <Card className="w-full max-w-md">
              <CardContent className="p-8 text-center">
                <AlertCircle className="w-16 h-16 text-orange-500 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Access Restricted</h2>
                <p className="text-gray-600 mb-6">
                  You are not registered as an owner. Only property owners can access the My Listings page.
                </p>
                <Button
                  onClick={handleRegisterAsOwner}
                  className="bg-slate-600 hover:bg-slate-700 text-white font-semibold px-6 py-2"
                >
                  Register as Owner
                </Button>
              </CardContent>
            </Card>
          </div>
        ) : (
          // Show listings for owners
          <div>
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">My Listings</h1>
              <p className="text-gray-600">Manage your property listings</p>
            </div>

            <div className="bg-white rounded-lg border border-gray-200 p-8 text-center">
              <div className="max-w-md mx-auto">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No listings yet</h3>
                <p className="text-gray-600 mb-6">
                  Start by adding your first property listing to showcase your properties to potential buyers and
                  renters.
                </p>
                <Button className="bg-slate-600 hover:bg-slate-700 text-white font-semibold px-6 py-2">
                  Add New Listing
                </Button>
              </div>
            </div>
          </div>
        )}
      </main>

      <Footer />
    </div>
  )
}
