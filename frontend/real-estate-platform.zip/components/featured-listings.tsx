import { PropertyCard } from "@/components/property-card"
import Link from "next/link"

const featuredProperties = [
  {
    id: 1,
    title: "Modern Lekki Penthouse",
    starkPrice: 3750, // Monthly rent in STARK tokens
    type: "rent" as const,
    image: "/lekki-penthouse.png",
    location: "Lekki Phase 1, Lagos",
    beds: 4,
    baths: 3,
    sqft: 2800,
  },
  {
    id: 2,
    title: "Luxury Ikoyi Villa",
    starkPrice: 6250, // Monthly rent in STARK tokens
    type: "rent" as const,
    image: "/ikoyi-villa.png",
    location: "Ikoyi, Lagos",
    beds: 5,
    baths: 4,
    sqft: 4500,
  },
  {
    id: 3,
    title: "Contemporary Abuja Home",
    starkPrice: 2875, // Monthly rent in STARK tokens
    type: "rent" as const,
    image: "/abuja-contemporary-home.png",
    location: "Maitama, Abuja",
    beds: 4,
    baths: 3,
    sqft: 3200,
  },
  {
    id: 4,
    title: "Victoria Island Apartment",
    starkPrice: 4500, // Monthly rent in STARK tokens
    type: "rent" as const,
    image: "/vi-apartment.png",
    location: "Victoria Island, Lagos",
    beds: 3,
    baths: 2,
    sqft: 2100,
  },
  {
    id: 5,
    title: "Banana Island Estate",
    starkPrice: 12500, // Monthly rent in STARK tokens
    type: "rent" as const,
    image: "/banana-island-estate.png",
    location: "Banana Island, Lagos",
    beds: 6,
    baths: 5,
    sqft: 6000,
  },
  {
    id: 6,
    title: "Cozy Surulere Flat",
    starkPrice: 2000, // Monthly rent in STARK tokens
    type: "rent" as const,
    image: "/surulere-flat.png",
    location: "Surulere, Lagos",
    beds: 2,
    baths: 2,
    sqft: 1200,
  },
]

export function FeaturedListings() {
  return (
    <section className="py-16 px-4 max-w-7xl mx-auto bg-background dark:bg-background">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold mb-4 text-foreground dark:text-foreground">
          Featured Properties
        </h2>
        <p className="text-muted-foreground dark:text-muted-foreground text-lg max-w-2xl mx-auto">
          Discover our handpicked selection of premium rental properties across Nigeria
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {featuredProperties.map((property) => (
          <Link key={property.id} href={`/listings/${property.id}`}>
            <PropertyCard property={property} />
          </Link>
        ))}
      </div>
    </section>
  )
}
